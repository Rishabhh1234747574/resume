# Overleaf project

- Upload the contents of this `overleaf/` folder to Overleaf.
- Ensure the main file is set to `main.tex` in Overleaf project settings.
- Compiler: pdfLaTeX is fine. If you see font/glyph warnings, switch to XeLaTeX.
- `glyphtounicode.tex` here is a minimal stub; you can remove it if your TeX Live includes it globally.